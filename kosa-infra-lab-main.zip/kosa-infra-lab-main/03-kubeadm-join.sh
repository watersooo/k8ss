#!/bin/bash
kubeadm join --config=kubeadm-join-config.yaml