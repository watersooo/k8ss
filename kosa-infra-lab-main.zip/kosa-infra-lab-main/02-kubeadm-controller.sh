#!/bin/bash
kubeadm init --config=kubeadm-config.yaml